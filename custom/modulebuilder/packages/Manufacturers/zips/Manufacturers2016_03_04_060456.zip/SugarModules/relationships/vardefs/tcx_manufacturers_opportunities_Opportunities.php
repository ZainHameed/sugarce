<?php
// created: 2016-03-04 06:04:56
$dictionary["Opportunity"]["fields"]["tcx_manufacturers_opportunities"] = array (
  'name' => 'tcx_manufacturers_opportunities',
  'type' => 'link',
  'relationship' => 'tcx_manufacturers_opportunities',
  'source' => 'non-db',
  'module' => 'tcx_Manufacturers',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_TCX_MANUFACTURERS_OPPORTUNITIES_FROM_TCX_MANUFACTURERS_TITLE',
);
