<?php
// created: 2016-03-04 06:04:56
$dictionary["Account"]["fields"]["tcx_manufacturers_accounts"] = array (
  'name' => 'tcx_manufacturers_accounts',
  'type' => 'link',
  'relationship' => 'tcx_manufacturers_accounts',
  'source' => 'non-db',
  'module' => 'tcx_Manufacturers',
  'bean_name' => false,
  'side' => 'right',
  'vname' => 'LBL_TCX_MANUFACTURERS_ACCOUNTS_FROM_TCX_MANUFACTURERS_TITLE',
);
